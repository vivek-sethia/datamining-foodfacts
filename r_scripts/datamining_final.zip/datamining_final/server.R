library(shiny)
library(shinydashboard)
library(NLP)
library(tm)
library(SnowballC)
library(wordcloud)
library(stringr)
library(ggplot2)
library(randomForest)
library(reshape)


beverage <- read.csv("beverage.csv", header = TRUE, stringsAsFactors = FALSE)
allergens <- read.csv("allergens.csv", header = TRUE, stringsAsFactors = FALSE)
packaging <- read.csv("packaging.csv", header = TRUE, stringsAsFactors = FALSE)
country <- read.csv("countries.csv", header = TRUE, stringsAsFactors = FALSE)
kategori_set <- read.csv("sugar_energy.csv", header = TRUE, stringsAsFactors = FALSE)
countries_fat1 <- read.csv("countries_fat1.csv", header = TRUE, stringsAsFactors = FALSE)
countries_sugar <- read.csv("countries_sugar.csv", header = TRUE, stringsAsFactors = FALSE)
beverage_set <- read.csv("beverage.csv", header = TRUE, stringsAsFactors = FALSE)
new_set <- read.csv("new_set.csv", header = TRUE, stringsAsFactors = FALSE)
foods_fact <- read.csv("food_fact.csv", header = TRUE, stringsAsFactors = FALSE)
sugar_beverages <- c(0, 0.9666667, 5.38, 6.149639, 6.66, 6.90625, 7.395, 8.752857, 10.8, 11.09, 11.72, 12.74562, 14.59, 14.76667, 39, 60, 61.36757)
wordcloud_rep <- repeatable(wordcloud)
foods_fact <- subset(foods_fact, select = -X)

#set a seed
set.seed(123)

#classify juice and non juice in beverage_set
beverage_set$type <- ifelse(str_detect(beverage_set$categories_tags, "juice"), 'Juice Beverage', 'Non-Juice Beverage' )
beverage_set$type[str_detect(beverage_set$categories_tags, '-jus-')] <- 'Juice Beverage'
beverage_set$type <- as.factor(beverage_set$type)

server <- function(input, output, session) {
  observeEvent(input$switchtab, {
    newtab <- switch(input$tabs, "open" = "world",
                     "open" = "scatter",
                     "open" = "sugar",
                     "open" = "protein",
                     "open" = "fiber",
                     "open" = "energy",
                     "open" = "bar",
                     "open" = "dist",
                     "open" = "allergens",
                     "open" = "packaging",
                     "open" = "country",
                     "open" = "predict",
                     "open" = "fat",
                     "open" = "sugar_country",
                     "open" = "sugarBeverage",
                     "open" = "sugarInBeverage",
                     "open" = "juice",
                     "open" = "juiceWhole",
                     "open" = "soda",
                     "open" = "healthy",
                     "open" = "morning",
                     "open" = "protein",
                     "open" = "other",
                     "sugar" = "protein",
                     "sugar" = "fiber",
                     "sugar" = "energy",
                     "world" = "open")
    updateTabItems(session, "tabs", newtab)
  })
  
  output$sugar <- renderPlot({
    
    x <- beverage$sugars_100g
    binsugar <- seq(min(x), max(x), length.out = input$binsugar + 1)
    
    hist(x, breaks = binsugar, col = 'darkgray', border = 'white', xlab = "Sugar per 100g", main = "Histogram of Sugar")
    
  })
  
  output$energy <- renderPlot({
    
    x <- beverage$energy_100g
    binenergy <- seq(min(x), max(x), length.out = input$binenergy + 1)
    
    hist(x, breaks = binenergy, col = 'darkgray', border = 'white', xlab = "Energy per 100g", main = "Histogram of Energy")
    
  })
  
  output$fiber <- renderPlot({
    
    x <- beverage$fiber_100g
    binfiber <- seq(min(x), max(x), length.out = input$binfiber + 1)
    
    hist(x, breaks = binfiber, col = 'darkgray', border = 'white', xlab = "Fiber per 100g", main = "Histogram of Fiber")
    
  })
  
  output$protein <- renderPlot({
    
    x <- beverage$proteins_100g
    binprotein <- seq(min(x), max(x), length.out = input$binprotein + 1)
    
    hist(x, breaks = binprotein, col = 'darkgray', border = 'white', xlab = "Protein per 100g", main = "Histogram of Protein")
    
  })
  
  output$allergens <- renderPlot({
    
    ###allergens
    wc_allergens <- Corpus(VectorSource(allergens))
    wc_allergens <- tm_map(wc_allergens, PlainTextDocument)
    wc_allergens <- tm_map(wc_allergens, removePunctuation)
    wc_allergens <- tm_map(wc_allergens, removeWords, stopwords('english'))
    wordcloud(wc_allergens, random.order = FALSE, random.color=TRUE,colors=rainbow(100), scale = c(4,2), min.freq = input$freq, max.words = input$max)
    
    
  })
  
  output$packaging <- renderPlot({
    
    ###allergens
    wc_allergens <- Corpus(VectorSource(packaging))
    wc_allergens <- tm_map(wc_allergens, PlainTextDocument)
    wc_allergens <- tm_map(wc_allergens, removePunctuation)
    wc_allergens <- tm_map(wc_allergens, removeWords, stopwords('english'))
    wordcloud(wc_allergens, random.order = FALSE, random.color=TRUE,colors=rainbow(100), scale = c(4,2), min.freq = input$freq, max.words = input$max)
    
    
  })
  
  output$country <- renderPlot({
    ###allergens
    wc_allergens <- Corpus(VectorSource(country))
    wc_allergens <- tm_map(wc_allergens, PlainTextDocument)
    wc_allergens <- tm_map(wc_allergens, removePunctuation)
    wc_allergens <- tm_map(wc_allergens, removeWords, stopwords('english'))
    wordcloud(wc_allergens, random.order = FALSE, random.color=TRUE,colors=rainbow(100), scale = c(4,2), min.freq = input$freq, max.words = input$max)
    
    
  })
  
  output$fat <- renderPlot({
    
    #make plot better
    op0 = par()	# Get current graphical parameters
    op1 = op0$mar  # Get current margins in lines
    op1[1] = 11	# Modify bottom margins to 20 (lines)
    op1			# View bottom margins in lines
    par(mar = op1)
    ##countries_en vs fat_100g
    plot(as.factor(countries_fat1$countries_en),countries_fat1$fat_100g, main = "Fat_100g based on Countries", ylab = "fat in gram" ,las = 3)
    
    
  })
  
  output$sugar_country <- renderPlot({
    
    #make plot better
    op0 = par()	# Get current graphical parameters
    op1 = op0$mar  # Get current margins in lines
    op1[1] = 11	# Modify bottom margins to 20 (lines)
    op1			# View bottom margins in lines
    par(mar = op1)
    ##countries_en vs fat_100g
    plot(as.factor(countries_sugar$countries_en),countries_sugar$sugars_100g, main = "Sugars_100g based on Countries", ylab = "sugars in gram", las = 3)
    
    
  })
  
  output$sugarBeverage <- renderPlot({
    
    plot(kategori_set$sugars_100g, kategori_set$energy_100g, xlab = "Sugar per 100g", ylab = "energy in Kj", main = "Sugar vs Energy in beverages")
  
  })
  
  output$sugarInBeverage <- renderPlot({
    
    #make plot better
    op0 = par()	# Get current graphical parameters
    op1 = op0$mar  # Get current margins in lines
    op1[1] = 11	# Modify bottom margins to 20 (lines)
    op1			# View bottom margins in lines
    par(mar = op1)
    ylim <- c(0, 1.1*max(sugar_beverages))
    beverages_sugar <- barplot(sugar_beverages, ylab = "Sugar per 100g", main = "Think Before You Drink", 
                               names.arg=c("Diet Coke", "Alcoholic Drink", "Coconut Drink", "Milk", "Pepsi", "Tea", 
                                           "Coffe Drink", "Coca Cola", "Ginger Cola", "Sprite", "Chocolate Milk", "Protein Shake", "Juices"
                                           , "Smoothies", "Power Drink", "Chocolate Drink", "Sirop"), col = c('darkblue'), las = 3, ylim = ylim)
    text(x = beverages_sugar, y = sugar_beverages, label = sugar_beverages, pos = 3, cex = 0.8, col = "red")
    
    
    
  })
  
  output$juice <- renderPlot({
    
    ggplot(beverage_set, aes(sugars_100g, fruits.vegetables.nuts_100g, color = type)) + geom_point()
    
  })
  
  output$juiceWhole <- renderPlot({
    
    ggplot(new_set, aes(sugars_100g, fruits.vegetables.nuts_100g, color = type)) + geom_point()
    
  })
  
  output$soda <- renderPlot({
    soda_drink <- foods_fact[1:4,]
    soda <- melt(soda_drink, id.vars = 'drink_name')
    ggplot(data = soda, aes(x = drink_name, y = value, fill = variable)) + 
      geom_bar(stat = 'identity', position = 'dodge', width = 0.9) + 
      geom_text(aes(label = value), position=position_dodge(width=0.9), vjust=-0.25) +
      ggtitle("Soda Drink")
    
  })
  
  output$healthy <- renderPlot({
    healthy_drink <- foods_fact[12:14,]
    healthy <- melt(healthy_drink, id.vars = 'drink_name')
    ggplot(data = healthy, aes(x = drink_name, y = value, fill = variable)) +
      geom_bar(stat = 'identity', position = 'dodge', width = 0.9) +
      geom_text(aes(label = value), position = position_dodge(width = 0.9), vjust = -0.25) +
      ggtitle('Healthy Drink')
    
  })
  
  output$morning <- renderPlot({
    morning_drink <- foods_fact[5:8,]
    morning <- melt(morning_drink, id.vars = 'drink_name')
    ggplot(data = morning, aes(x = drink_name, y = value, fill = variable)) + 
      geom_bar(stat = 'identity', position = 'dodge', width = 0.9) + 
      geom_text(aes(label = value), position=position_dodge(width=0.9), vjust=-0.25) +
      ggtitle("Morning Drink")
    
  })
  
  output$protein_drink <- renderPlot({
    protein_drink <- foods_fact[15:16,]
    protein <- melt(protein_drink, id.vars = 'drink_name')
    ggplot(data = protein, aes(x = drink_name, y = value, fill = variable)) +
      geom_bar(stat = 'identity', position = 'dodge', width = 0.9) +
      geom_text(aes(label = value), position = position_dodge(width = 0.9), vjust = -0.25) +
      ggtitle('Protein and Energy Drink')
    
  })
  
  output$other <- renderPlot({
    other_drink <- foods_fact[9:11,]
    other <- melt(other_drink, id.vars = 'drink_name')
    ggplot(data = other, aes(x = drink_name, y = value, fill = variable)) + 
      geom_bar(stat = 'identity', position = 'dodge', width = 0.9) + 
      geom_text(aes(label = value), position=position_dodge(width=0.9), vjust=-0.25) +
      ggtitle("Other Drink")
    
  })
  
  
}






