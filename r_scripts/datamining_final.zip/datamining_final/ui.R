library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Open Food Facts"),
  dashboardSidebar(
    width = 300,
    sidebarMenu(id = "tabs",
                menuItem("About", tabName = "about", icon = icon("dashboard"),
                         menuSubItem("Open Food Facts", tabName = "open", icon = icon("th")),
                         menuSubItem("World Food Facts Team", tabName = "world", icon = icon("th"))),
                menuItem("Chart", tabName = "chart", icon = icon("line-chart"),
                         menuItem("Scatter Plot", tabName = "scatter", icon = icon("area-chart"),
                                  menuSubItem("Sugar vs Energy in Beverage", tabName = "sugarBeverage")),
                         menuItem("Histogram", tabName = "hist", icon = icon("bar-chart"),
                                     menuSubItem("Sugar Histogram", tabName = "sugar"),
                                  menuSubItem("Energy Histogram", tabName = "energy"),
                                  menuSubItem("Protein Histogram", tabName = "protein"),
                                  menuSubItem("Fiber Histogram", tabName = "fiber")),
                         menuItem("Bar Plot", tabName = "bar", icon = icon("bar-chart"),
                                  menuSubItem("Sugar in Beverage", tabName = "sugarInBeverage"),
                                  menuSubItem("Soda Drink Nutrition", tabName = "soda"),
                                  menuSubItem("Healthy Drink Nutrition", tabName = "healthy"),
                                  menuSubItem("Morning Drink Nutrition", tabName = "morning"),
                                  menuSubItem("Protein Drink Nutrition", tabName = "protein_drink"),
                                  menuSubItem("Other Drink Nutrition", tabName = "other")),
                         menuItem("Distribution Plot", tabName = "dist", icon = icon("area-chart"),
                                  menuSubItem("Countries and Fat Distribution", tabName = "fat"),
                                  menuSubItem("Countries and Sugar Distribution", tabName = "sugar_country"))),
                menuItem("WordCloud", tabName = "word", icon = icon("cloud"),
                         menuSubItem("Allergens Wordcloud", tabName = "allergens"),
                         menuSubItem("Packaging Wordcloud", tabName = "packaging"),
                         menuSubItem("Countries Wordcloud", tabName = "country")),
                menuItem("Prediciton Task", tabName = "predict", icon = icon("hacker-news"),
                         menuSubItem("Juice in Whole Data", tabName = "juiceWhole"),
                         menuSubItem("Juice in Beverage Data", tabName = "juice"))
                
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "open",
              fluidPage(
                sidebarLayout(position = "right",
                              sidebarPanel( h1(strong("Open Food Facts")),
                                            h3("The free food products database."),
                                            h4("Tell me what you eat and I will tell you what you are."),
                                            h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                              mainPanel(
                                img(src="openfoodfact.png", height = 300, width = 980),
                                br(),
                                br(),
                                h2(strong("Open your food and know what you eat"), align = "center"),
                                h3("Be part of our collaborative, free and open database of food products from around the world", align = "center"),
                                br(),
                                column(4,img(src= "food1.png", height = 250, width = 300)),
                                column(4,img(src= "food2.png", height = 250, width = 300)),
                                column(4,img(src= "food3.png", height = 250, width = 300)),
                                column(4,h4("Open Food Facts is a database of food products with ingredients, allergens, nutririon facts and other informations which we can find  on product labels", align = "center")),
                                column(4,h4("Open Food Facts is a non-profit association of volunteers. +1800 contributors, +75000 products from 150 countries using our Android, 
                                            iPhone, Windows Phone App or scan barcodes and upload pictures and their labels", align = "center")),
                                column(4,h4("Data about food is of public interest and has to be open. The complete database is published as open data and can be reused by anyone and for any use."), align = "center"),
                                br(),
                                br(),
                                h4(strong("EAT REAL FOOD FEEL REAL GOOD!!"), align = "center"),
                                br(),
                                h2(strong("Make a better food choices"), align = "center"),
                                h3("Knowledge is power. Food knowledge is power to eat better!", align = "center"),
                                br(),
                                column(3,img(src= "food4.png", height = 200, width = 220)),
                                column(3,img(src= "food5.png", height = 200, width = 220)),
                                column(3,img(src= "food6.png", height = 200, width = 220)),
                                column(3,img(src= "food7.png", height = 200, width = 220)),
                                column(3,h4("Food additives E-numbers, allergens, packaging codes, etc.. Open Food Facts helps you to make sense of the fine print on products labels.", align = "center")),
                                column(3,h4("Our", a("search form", href = "https://world.openfoodfacts.org/cgi/search.pl"),  "includes dozens of criteria so that you can find product that match your criteria", align = "center")),
                                column(3,h4("Do you know which breakfast cereals have th eless fat and sugar? In 3 clicks you can create an interactive graph to show it. 
                                            So you can change for healthier cereals and by comparing products from different brands, you encourage producers to make them better", align = "center")),
                                column(3,h4("Curious about food? Explore products by facets like, categories, labels, origins of ingredients, etc.. Facets can be combined to discover new insight, for instance to map the",
                                            a("origins of ingredients that bear a fair trade label.", href = "https://world.openfoodfacts.org/label/fair-trade/origins"), align = "center")),
                                br(),
                                h4(strong("DON'T USE YOUR STOMACHE as a TRASH CAN!!"), align = "center"),
                                br(),
                                h2(strong("Food for thought, innovation and science"), align = "center"),
                                h3("Our data can be reused for education , new products and services, research and more!", align = "center"),
                                h3("The Open Food Facts database is open data published under the Open Database License. Anyone can use it for any purpose - commercial or non- commercial 
                                   provided the source of the data is attributed and imporvements to the database are shared in a similar way", align = "center"),
                                br(),
                                column(4,h3(strong("Education"), align = "center")),
                                column(4,h3(strong("Product and Services"), align = "center")),
                                column(4,h3(strong("Science"), align = "center")),
                                column(4,h4("How many food commercials have you seen in your life? Open data can help to see the facts under the marketing.", align = "center")),
                                column(4,h4("Open Food Facts data can be reused in both non-commercial and commercial projects, as long as imporvements to the database are shared as well", align = "center")),
                                column(4,h4("Open Food Facts data is used by scientists in different fields (Nutrition, Biology, Linked Open Data, etc.). And you don'y need a PhD to take part in citizen science!", align = "center")),
                                column(4,img(src= "food8.png", height = 250, width = 300)),
                                column(4,img(src= "food9.png", height = 250, width = 300)),
                                column(4,img(src= "food10.png", height = 250, width = 300)),
                                column(4,h4("Can you guess the equivalent amount of sugar cubes in your food? try", a("How much sugar?", href = "http://howmuchsugar.in/"),  "to find out.", align = "center")),
                                column(4,h4("Know where your food comes form and Eat Local wit", a("Made Near Me!", href = "http://madenear.me/"), align = "center")),
                                column(4,h4("The French National Nutrition and Health Program uses Open Food Facts data to validate the formula of its nutrition quality score and nutrition grades", align = "center"))
                                
                              ))
              )
      ),
      tabItem(tabName = "world",
              fluidPage(
                sidebarLayout(
                  position = "right",
                  sidebarPanel( h1(strong("Open Food Facts")),
                                h3("The free food products database."),
                                h4("Tell me what you eat and I will tell you what you are."),
                                h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                  mainPanel(
                    img(src="openfoodfact.png", height = 300, width = 980),
                br(),
                br(),
                br(),
                h1(strong("World Food Facts Team"), align = "center"),
                h1(strong("Data Mining Lab Course Winter 2016/2017"), align = "center"),
                br(),
                br(),
                fluidRow(column(4,img(src= "Andi.jpeg", height = 250, width = 300)),
                         column(4,img(src= "windu.jpg", height = 250, width = 300)),
                         column(4,img(src= "vivek.jpeg", height = 250, width = 300)),
                         column(4,h3("Andreas Kammerloher", align = "center")),
                         column(4,h3("Muhammad Triwindu Prasetya", align = "center")),
                         column(4,h3("Vivek Sethia", align = "center"))
                        ),
                br(),
                br(),
                br(),
                h2(strong("About Open Food Fact Dataset")),
                br(),
                h3(strong("1. Dataset Description:")),
                h3("* Size: 267 MB"),
                h3("* Attributes: 159"),
                h3("* Format: .csv"),
                h3("* Entry-count: 106458"),
                h3("* Missing Values: 12.818.231 cells"),
                br(),
                h2(strong("Attributes:")),
                h3("* product_name (text)"),
                h3("* sugar quantity (number)"),
                h3("* fat quantity (number)"),
                h3("* energy quantity (number)"),
                h3("* sodium quantity (number)"),
                h3("* quantity (text)"),
                h3("* countries (text)"),
                h3("* categories (text)"),
                h3("* allergens (text)"),
                h3("* additives (text)"),
                h3("* And so on..."),
                br(),
                h3("There are a lot of food products that exist in the world. It wuld be interesting to explore the composition of the food, their similarities with others and also looking
                   at the from a health point of view."),
                br(),
                h2(strong("Dataset Link")),
                h4("Dataset can be found at -", a("Open Food Fact", href = "https://world.openfoodfacts.org/")),
                br(),
                br(),
                img(src="openfoodfact.png", height = 200, width = 1020)
                
              )
            )
          )
        ),
      tabItem(tabName = "sugar",
              fluidPage(
                sidebarLayout(
                  position = "right",
                  sidebarPanel( h1(strong("Open Food Facts")),
                                h3("The free food products database."),
                                h4("Tell me what you eat and I will tell you what you are."),
                                h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                  mainPanel(
                    img(src="openfoodfact.png", height = 270, width = 997),
                    br(),
                    br(),
                    sliderInput("binsugar",
                                h1("Number of bins:"),
                                min = 1,
                                max = 50,
                                value = 30),
                    plotOutput('sugar', height = "500px")
                  )
                )
              )
    ),
    tabItem(tabName = "protein",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  sliderInput("binprotein",
                              h1("Number of bins:"),
                              min = 1,
                              max = 50,
                              value = 30),
                  plotOutput('protein', height = "500px")
                )
              )
            )
    ),
    tabItem(tabName = "energy",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  sliderInput("binenergy",
                              h1("Number of bins:"),
                              min = 1,
                              max = 50,
                              value = 30),
                  plotOutput('energy', height = "500px")
                )
              )
            )
    ),
    tabItem(tabName = "fiber",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  sliderInput("binfiber",
                              h1("Number of bins:"),
                              min = 1,
                              max = 50,
                              value = 30),
                  plotOutput('fiber', height = "500px")
                )
              )
            )
    ),
    tabItem(tabName = "allergens",
            fluidPage(
              sidebarLayout(
                # Sidebar with a slider and selection inputs
                sidebarPanel(
                  
                  h4(strong("Change the configuration")),
                  hr(),
                  sliderInput("freq",
                              "Minimum Frequency:",
                              min = 1,  max = 50, value = 15),
                  sliderInput("max",
                              "Maximum Number of Words:",
                              min = 1,  max = 300,  value = 100)
                ),
                
                # Show Word Cloud
                mainPanel(
                  br(),
                  br(),
                  plotOutput("allergens"),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  img(src="openfoodfact.png", height = 300, width = 1000)
                )
              )
            )
    ),
    
    tabItem(tabName = "packaging",
            fluidPage(
              sidebarLayout(
                # Sidebar with a slider and selection inputs
                sidebarPanel(
                  
                  h4(strong("Change the configuration")),
                  hr(),
                  sliderInput("freq",
                              "Minimum Frequency:",
                              min = 1,  max = 50, value = 15),
                  sliderInput("max",
                              "Maximum Number of Words:",
                              min = 1,  max = 300,  value = 100)
                ),
                
                # Show Word Cloud
                mainPanel(
                  br(),
                  br(),
                  plotOutput("packaging"),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  img(src="openfoodfact.png", height = 300, width = 1000)
                )
              )
            )
    ),
    
    tabItem(tabName = "country",
            fluidPage(
              sidebarLayout(
                # Sidebar with a slider and selection inputs
                sidebarPanel(
                  
                  h4(strong("Change the configuration")),
                  hr(),
                  sliderInput("freq",
                              "Minimum Frequency:",
                              min = 1,  max = 50, value = 15),
                  sliderInput("max",
                              "Maximum Number of Words:",
                              min = 1,  max = 300,  value = 100)
                ),
                
                # Show Word Cloud
                mainPanel(
                  br(),
                  br(),
                  plotOutput("country"),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  br(),
                  img(src="openfoodfact.png", height = 300, width = 1000)
                )
              )
            )
    ),
    
    tabItem(tabName = "fat",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('fat', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "sugar_country",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('sugar_country', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "sugarBeverage",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('sugarBeverage', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "sugarInBeverage",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('sugarInBeverage', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "juiceWhole",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('juiceWhole', height = "550px"),
                  br(),
                  column(4,h3(strong(" Random Forest Result:"),
                              h4("Number of Trees = 500"),
                              h4("Accuracy = 0.985"),
                              h4("Precision = 0.588"),
                              h4("Recall = 0.850"),
                              h4("F1 score = 0.695")))
                )
              )
            )
    ),
    
    tabItem(tabName = "juice",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('juice', height = "550px"),
                  br(),
                  column(4,h3(strong(" Random Forest Result:"),
                              h4("Number of Trees = 500"),
                              h4("Accuracy = 0.966"),
                              h4("Precision = 0.633"),
                              h4("Recall = 0.863"),
                              h4("F1 score = 0.730"))),
                  column(4,h3(strong(" NaiveBayes Result:"),
                              h4("Accuracy = 0.5232"),
                              h4("Precision : 0.976"),
                              h4("Sensitivity : 0.975"),
                              h4("Recall : 0.123"),
                              h4("F1 - Score : 0.219"),
                              h4("Pos Pred Value : 0.124"),
                              h4("Neg Pred Value : 0.996"),
                              h4("Balanced Accuracy : 0.732")))
                  
                )
              )
            )
    ),
    
    tabItem(tabName = "soda",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('soda', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "healthy",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('healthy', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "morning",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('morning', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "protein_drink",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('protein_drink', height = "550px")
                )
              )
            )
    ),
    
    tabItem(tabName = "other",
            fluidPage(
              sidebarLayout(
                position = "right",
                sidebarPanel( h1(strong("Open Food Facts")),
                              h3("The free food products database."),
                              h4("Tell me what you eat and I will tell you what you are."),
                              h6(em("- Jean Anthelme Brillat-Savarin - 1825"))),
                mainPanel(
                  img(src="openfoodfact.png", height = 270, width = 997),
                  br(),
                  br(),
                  br(),
                  br(),
                  plotOutput('other', height = "550px")
                )
              )
            )
    )
    
  )
)
)


